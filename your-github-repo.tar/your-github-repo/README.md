Project Overview

This project implements log schema validation,
anomaly detection, and system architecture
for monitoring logs efficiently.
