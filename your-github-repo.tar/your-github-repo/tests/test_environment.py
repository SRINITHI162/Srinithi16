print("Environment test successful")

