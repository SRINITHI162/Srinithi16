System Architecture Explanation

Logs are generated from applications.
They are collected and processed.
The analyzer detects anomalies.
Alerts are sent if issues occur.
